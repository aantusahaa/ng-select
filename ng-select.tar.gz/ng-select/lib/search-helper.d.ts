export declare function stripSpecialChars(text: string): string;
