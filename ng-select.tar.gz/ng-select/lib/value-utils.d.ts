export declare function escapeHTML(value: string): string;
export declare function isDefined(value: any): boolean;
export declare function isObject(value: any): boolean;
export declare function isPromise(value: any): value is Promise<any>;
export declare function isFunction(value: any): boolean;
