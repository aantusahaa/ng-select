export declare function newId(): string;
