import * as i0 from "@angular/core";
export declare class ConsoleService {
    warn(message: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConsoleService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ConsoleService>;
}
