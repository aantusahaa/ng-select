/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@antu/ng-select" />
export * from './public-api';
